<?php

$servername="localhost";
$username="id19735575_admin";
$password="Ritik@6306707440";
$database_name="id19735575_carselling";

$config  = mysqli_connect($servername,$username,$password,$database_name);

if($config ){
    // echo"ok";
 }
else{echo "Failed";}
